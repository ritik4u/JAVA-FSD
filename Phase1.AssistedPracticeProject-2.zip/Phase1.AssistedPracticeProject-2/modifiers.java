package simpli;


class check{

	
	 
	  void display() 
	     { 
	         System.out.println(" defalut access specifier"); 
	     } 
} 


	
public class modifiers {

	public static void main(String[] args) {
	
		System.out.println("Dafault Access Specifier");
		check c = new check(); 		  
        c.display(); 

	}
}
