package simpli;



 class modifier3{

	protected void display() 
    { 
        System.out.println("this is protected"); 
    } 
}


public class modifier2 extends modifier3{

	public static void main(String[] args) {
		modifier3  ob = new modifier3 ();   
	       ob.display();  
	}

}