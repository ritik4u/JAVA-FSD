


class test1{
	public void display() {
		 System.out.println("im a public");
	}
	//private void show(){
	//System.out.println("im a private");
//}
}

public class modifier4 {
	public static void main(String[] args) {
		test1 o=new test1();
		o.display();
	//	o.show(); private method can't be used 
	
	}

}
