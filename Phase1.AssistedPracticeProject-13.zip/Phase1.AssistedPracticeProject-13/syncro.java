
package simpli;
class print1{  
 synchronized void display(int n){
   for(int i=1;i<=4;i++){  
     System.out.println("this is thread");  
     try{  
      Thread.sleep(1000);  
     }catch(Exception e){System.out.println(e);}  
   }  
  
 }  
}  
  
class print2 extends Thread{  
print1 t;  
print2(print1 t){  
this.t=t;  
}  
public void run(){  
t.display(7);  
}  
  
}  
class print3 extends Thread{  
print1 t;  
print3(print1 t){  
this.t=t;  
}  
public void run(){  
t.display(100);  
}  
}  
  
public class syncro{  
public static void main(String args[]){  
print1 n = new print1();
print2 t1=new print2(n);  
print3 t2=new print3(n);  
t1.start();  
t2.start();  
}  
}  

