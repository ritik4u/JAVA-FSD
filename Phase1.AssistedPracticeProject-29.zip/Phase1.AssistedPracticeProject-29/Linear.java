package sort;

public class Linear{    
public static int linearSearch(int[] arr, int item){    
        for(int i=0;i<arr.length;i++){    
            if(arr[i] == item){    
                return i;    
            }    
        }    
        return -1;    
    }    
    public static void main(String a[]){    
        int a1[]= {12,41,89,92,101};    
        int item = 92;    
        System.out.println(item+"  found at  position : "+linearSearch(a1, item));    
    }    
}    