package simpli;
class info extends Exception{
	private int data;
	public info(int age) {
		data=age;
		
	}
	public String toString() {
		return "info["+data+")";
	}
	
}
public class exhandle {
	static void print(int age )throws info{
		System.out.println("the age is ("+age+")");
		if (age>10) 
			throw new info(age);
			System.out.println("exit the panel");
		
	}

	public static void main(String[] args) {
		try {
			print(1);
			print(34);
			print(12);
		} catch (info e) {
			System.out.println("Caught exception !!");
			e.printStackTrace();
		}
	
		
	}
}
