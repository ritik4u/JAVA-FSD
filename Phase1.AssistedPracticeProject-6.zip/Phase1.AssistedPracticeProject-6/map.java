package simpli;
import java.util.*;

public class map {
	

		public static void main(String[] args) {
			// map
			
			//Hashmap
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(31,"ritik");    
		      hm.put(90,"hello");    
		      hm.put(33,"me");   
		       
		      System.out.println(" Hashmap are ");  
		      for(Map.Entry m:hm.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		     //HashTable
		       
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(84,"nine");  
		      ht.put(35,"toss");  
		      ht.put(36,"mom");  
		      ht.put(87,"pop");  

		      System.out.println(" HashTable are ");  
		      for(Map.Entry n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		      //TreeMap
		      
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(28,"nimo");    
		      map.put(92,"Cmllcdlc");    
		      map.put(80,"Cccnnn");       
		      
		      System.out.println("TreeMap are ");  
		      for(Map.Entry l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
	}



