package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest {
	
	WebDriver wd=null;	
	@BeforeTest	
		public void init() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Ritik\\Downloads\\chromedriver-win32\\chromedriver.exe");

	    	 wd=new ChromeDriver();
	    	
	    	wd.manage().window().maximize();
	}
	
  @Test(priority = 1)
  public void f() throws InterruptedException {
	  wd.get("http://127.0.0.1:62688/projectng/registration.html");
	  wd.findElement(By.id("username")).sendKeys("root");
	  Thread.sleep(1000);
	  wd.findElement(By.id("password")).sendKeys("root");
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("//*[@id=\"registrationForm\"]/button")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.id("username")).sendKeys("root");
	  Thread.sleep(1000);
	  wd.findElement(By.id("password")).sendKeys("root");
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("//*[@id=\"loginForm\"]/button")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.id("searchInput")).sendKeys("Product B");
	  Thread.sleep(1000);
	  wd.findElement(By.id("searchButton")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("//*[@id=\"products\"]/li[1]/button")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("//*[@id=\"products\"]/li[2]/button")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("//*[@id=\"products\"]/li[3]/button")).click();
	  Thread.sleep(1000);
	  
	  
  }
  @Test(priority = 2)
	public void test2() throws InterruptedException {
		wd.get("http://127.0.0.1:62688/projectng/login.html");
		 // Login form elements
		 WebElement emailFieldLogin = wd.findElement(By.id("username"));
		
		 WebElement passwordFieldLogin = wd.findElement(By.id("password"));
		 Thread.sleep(1000);
		 WebElement loginButton = wd.findElement(By.xpath("//*[@id=\"loginForm\"]/button"));
		 // Enter invalid login credentials
		 emailFieldLogin.sendKeys("invalid@example.com");
		 Thread.sleep(1000);
		 passwordFieldLogin.sendKeys("invalidpassword");
		 Thread.sleep(1000);
		 // Click the login button
		 loginButton.click();
		 Thread.sleep(1000);

		 // takeScreenshot(driver,"LoginFailure");

		 // Wait for the error message (you can add some delays here if needed)
		// WebElement successMessage = driver.findElement(By.id("errorMsg"));
		// Assert.assertEquals(successMessage.getText(), "Login successfully....!");
		 WebElement errorMessage = wd.findElement(By.id("loginMessage"));
		 Assert.assertEquals(errorMessage.getText(), "Invalid login credentials. Please try again.");
	}
	
  
  @AfterTest
  public void close() {
	  wd.close();
  }
}
