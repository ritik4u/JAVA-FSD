package sort;

public class selection {
	static void sort(int a[],int n) {
		for(int i=0;i<n;i++) {
			int min =i;
			for(int j=i+1;j<n;j++) {
				if (a[j]<a[min]) {
					min=j;
				}
				
			}
			int temp=a[min];//here placing minimum value to the index so we use this
			a[min]=a[i];
			a[i]=temp;
			
		}
		
	}
	public static void main(String args[]) {
		int a[]= {15,24,16,3,13};
		int n=a.length;
		
				
				
		sort(a,n);
		// sorted array
				for(int i=0;i<a.length;i++) {
					System.out.println("sorted  array is "+a[i]);
				}
				
	}

}
