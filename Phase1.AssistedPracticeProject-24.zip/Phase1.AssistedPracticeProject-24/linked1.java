package practo1;

import java.util.LinkedList;

public class linked1 {
	public static void main(String[] args) {
		LinkedList<Integer> list= new LinkedList<Integer>();
			list.add(23);
			list.add(34);
			list.add(89);
			list.add(29);
			list.add(47);
			list.add(12);
			list.remove(0);
			
			for(int i:list) {
				System.out.println("linked list after deleting"+i);
				
			}
		}
	}
	


