package trick;
interface A1{
	default void print1() {
		System.out.println("im a method of A1");
		
	}
}
interface A2 extends A1{
	default void print2() {
		System.out.println("im a method of A2");
		
	}
		
	}
	

interface A3 extends A1{
	default void print3() {
		System.out.println("im a method of A3");
		
	}
	
	
}

public class diamond implements A2,A3{
	public static void main(String[] args) {
		diamond d= new diamond();
		d.print1();
		d.print2();
		d.print3();
	}

}
