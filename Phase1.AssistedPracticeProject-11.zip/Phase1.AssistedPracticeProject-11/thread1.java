package simpli;

import java.util.Scanner;

public class thread1 extends Thread{
	
		public void run() {
			
				Scanner scanner =new Scanner(System.in);
				int a=scanner.nextInt();
				int b=scanner.nextInt();
				int result=a+b;
				System.out.println("thread is working");
				System.out.println("result of addition"+result);
				
			
		}
	
	public static void main(String[] args) {
		thread1 ob1=new thread1();
		ob1.start();
		
		
	}

}
