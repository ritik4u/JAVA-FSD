package simpli;

public class runnable implements Runnable {
	int a,b;
	public void MUL(int a ,int b) {
		this.a=a;
		this.b=b;
         int result =a*b;
         System.out.println(result);
	}
	public void run() {
		for(int i=1;i<4;i++) {
			System.out.println("thread is running");
		}
	}
	public static void main(String[] args) {
		runnable run = new runnable();
		run.MUL(12,3);
		Thread t1=new Thread(run);
		t1.start();
		
	}

}
