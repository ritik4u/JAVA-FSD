package simpli;

import java.util.Scanner;

public class try1 {
	
	public static void main(String[] args) {
		try {
		int d,a,c=10;
		d=0;
		a=45/d;
		System.out.println("this will not printed");
		}catch (ArithmeticException e) {
			System.out.println("Divison by zero");
		}
		System.out.println("main print");
		
	}
	

}
