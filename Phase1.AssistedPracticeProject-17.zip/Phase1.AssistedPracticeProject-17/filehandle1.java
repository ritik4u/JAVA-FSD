package simpli;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class filehandle1 {
	public static void main(String[] args) {
		File f1 = new File("E://practo//amit.txt");
		try {
			if(f1.createNewFile()) {
				System.out.println("file is created ");
			}
			else {
				System.out.println("file is created or file is already available");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			FileWriter f2= new FileWriter(f1);
			f2.write("file is here what are you doing");
			f2.write("\n how are you");
			f2.append("\n im from delhi");
			f2.append("\n i love india");
			f2.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {  
			 
			 File f3 = new File("E://practo//amit.txt"); 
	            Scanner sc = new Scanner(f3);  
	            while (sc.hasNextLine()) {  
	                String info = sc.nextLine();  
	                System.out.println(info);  
	            }  
	            sc.close();  
	        } catch (FileNotFoundException exception) {  
	            System.out.println("Unexcpected error occurred!");  
	            exception.printStackTrace();  
	        }  
		File myFile = new File("E://practo//amit.txt");
        if(myFile.delete()){
            System.out.println("I have deleted: " + myFile.getName());
        }
        else{
            System.out.println("Some problem occurred while deleting the file");
        }
		
	}
		
		
		
		
	}


