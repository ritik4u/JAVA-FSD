package practo1;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        next = null;
    }
}

public class linkedsort{
    Node head;

    linkedsort() {
        head = null;
    }

    
    void insert(int data) {
        Node newNode = new Node(data);


        if (head == null) {
            head = newNode;
            head.next = head; 
            return;
        }

       
        if (data < head.data) {
            newNode.next = head;


            Node last = head;
            while (last.next != head) {
                last = last.next;
            }
            last.next = newNode;

            head = newNode;  // Update the head reference
            return;
        }


        Node current = head;
        while (current.next != head && current.next.data < data) {
            current = current.next;
        }

        newNode.next = current.next;
        current.next = newNode;
    }

    
    void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        linkedsort circularList = new linkedsort();


        circularList.insert(2);
        circularList.insert(4);
        circularList.insert(6);
        circularList.insert(8);
        circularList.insert(10);


        circularList.display();
    }
}

