package simpli;
class ritik extends Exception{
	 private int detail;
	public ritik(int a) {
		detail=a;
		
	}
	public String toString(){
	return "ritik["+detail+"]";
	}
}
public class cutsom {
	static void print(int a) throws ritik{
		System.out.println("called print("+a+")");
		if (a>10) 
			throw new ritik(a);
			System.out.println("exit");
		
		
	}
	public static void main(String[] args) {
		try{
		print(1);
		print(20);
		}catch (Exception e) {
			System.out.println("exception occured"+e);
		}
		finally {
			System.out.println("Hi i am a finally  block!!");
		}
	}

}
