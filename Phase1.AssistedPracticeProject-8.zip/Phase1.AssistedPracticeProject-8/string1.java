package simpli;

import java.util.Scanner;
        public class string1 {
		public static void main(String[] args) {
			Scanner sc =new Scanner(System.in);
			System.out.println("enter first string");
			String a = sc.next();
			System.out.println("enter second string");
			String b =sc.next();
			System.out.println("enter third string");
			String c =sc.next();
			 System.out.println(a.length());
			 System.out.println(a.substring(3));
			 System.out.println(a.compareTo(b));
			 System.out.println(b.isEmpty());
			 System.out.println(c.toLowerCase());
			 System.out.println(a.equals(b));
			 System.out.println(a.replace('a','b'));   
			 System.out.println("StringBulider");
			 StringBuilder f = new StringBuilder(a);
			 System.out.println(f.append("ritik"));
			 System.out.println(f.insert(0, "programming"));
			 System.out.println(f.reverse());
			 System.out.println("StringBuffer");
			 StringBuffer s = new StringBuffer(c);
			 System.out.println(s.append("lily"));
			 System.out.println(s.delete(0, 2));
			 System.out.println(s.insert(0, 'T'));
			
			
			
			
			
		}

	}


