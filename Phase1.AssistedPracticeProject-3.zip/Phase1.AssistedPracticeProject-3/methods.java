package simpli;
 class A{
	 int a ,b,c;
	public void put(int a,int b,int c) {
		this.a=a;
		this.b=b;
		this.c=c;
		int d= a+b+c;
		
		System.out.println("hello  im a put method"+d);
		
	}
	public void put(int m,int n) {
		int c=m*n;
		System.out.println("hello  im a put 2nd method"+c);
	}
	public void bark()
	{
		System.out.println("barking");
		
	}
}
 
 class tree extends A{
	   public void yes(){
		   
		super.bark();
	 }
	 
 }
public class methods extends tree {
	public static void main(String args[]) {
		tree t =new tree();
		t.put(12,13);
		t.put(12,13,14);
		t.bark();
		t.yes();
		
	}

}
