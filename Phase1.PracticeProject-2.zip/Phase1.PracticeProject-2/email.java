package simpli;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class email {
	public static void main(String args[]) {
		System.out.println(" E-mail validation system");
		pass();

}
	public static void  pass() {
		String eval="^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z-]+\\.)+[a-zA-Z]{2,6}";
		Scanner sc=new Scanner(System.in);
		System.out.println("\n enter your Email Id");
		String str=sc.nextLine();
		Pattern pat=Pattern.compile(eval);
		Matcher m=pat.matcher(str);
		if(m.find()) {
			System.out.println("\n Correct Email Id");
		}
		else {
			System.out.println("\n Wrong Email Id");
		}
		
	}
}

