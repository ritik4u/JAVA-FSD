package simpli;
import java.util.*;

public class email {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Email to be find: ");
		String str = sc.next();
	 ArrayList <String> emails = new ArrayList<String>(); 
	  emails.add("riitk@gmail.com");
	  emails.add("amama@gmail.com");
	  emails.add("shreyas@gmail.com");
	  emails.add("megha@gmail.com");
	  emails.add("skashi@gmail.com");
	  emails.add("hii@gmail.com");
	  HashSet<String> set = new HashSet<String>(emails);
	  if (set.contains(str))
	  {
	    System.out.println("Email is found ");
	  }
	  else
	  {
		  System.out.println("Email is not found ");
	  }
	}
}

