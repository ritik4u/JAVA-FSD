package simpli;
import java.io.*;
import java.lang.*;
import java.lang.Math;
import java.util.Scanner;


public class calc{

	public static void main(String[] args)
	{
		
		double n1, n2;

	
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the numbers:");

		n1 = sc.nextDouble();
		n2 = sc.nextDouble();

		System.out.println("Enter the operator (+,-,*,/):");

		char choice = sc.next().charAt(0);
		double result = 0;

		switch (choice) {
		
		case '+':
			result = n1 + n2;
			break;

		
		case '-':
			result = n1 - n2;
			break;

		
		case '*':
			result = n1 * n2;
			break;

		case '/':
			result = n1 / n2;
			break;

		default:
			System.out.println("You enter wrong input");
		}

		System.out.println("The final result:");
		System.out.println();

		
		System.out.println(n1 + " " + choice + " " + n2
						+ " = " + result);
	}
}

