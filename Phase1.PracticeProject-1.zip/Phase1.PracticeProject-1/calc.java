package simpli;

import java.util.Scanner;

public class calc{
	public static void main(String args[]) {
	
		int choice,n1 ,n2;
		System.out.println( " 1. Add  \n 2. Subtract\n 3. Multiply \n 4. Divide");
		System.out.println("choose your choice");
		Scanner sc = new Scanner(System.in);
		choice=sc.nextInt();
		System.out.println("Enter your First number");
	    n1 =sc.nextInt();
	    System.out.println("Enter your second number");
		n2=sc.nextInt();
		int result=0;
		switch (choice) {
		case 1: {
			
			result=n1+n2;
			break;
		}
		case 2:
		{
			result=n1-n2;
			
		}
		case 3:
		{
			result=n1*n2;
		
		}
		case 4:
		{
			result=n1/n2;
		}
		default:
		{
			System.out.println(" Unexpected value: " );
		}
		
		
	}
		System.out.println("result of values is value: " +result);

}
}
