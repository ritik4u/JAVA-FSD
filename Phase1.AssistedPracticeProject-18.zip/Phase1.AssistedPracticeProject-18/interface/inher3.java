package simpli;

class Ab{
	void display1()
	{	
		System.out.println("hello im a display of class A");
    }
}
class B extends Ab{
	void display2()
	{	
		System.out.println("hello im a display of class B");
    }
}
class C extends Ab{
	void display3()
	{	
		System.out.println("hello im a display of class C");
    }
}
class D extends Ab{
	void display4()
	{	
		System.out.println("hello im a display of class D");
    }
}

public class inher3 {
	public static void main(String[] args) {
		B ob1= new B();
		C ob2=new C();
		D ob3= new D();
		ob1.display1();
		ob1.display2();
		ob2.display1();
		ob2.display3();
		ob3.display1();
		ob3.display4();
		}
	}
