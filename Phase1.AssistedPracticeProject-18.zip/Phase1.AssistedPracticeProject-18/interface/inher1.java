package learning;
class A {
	public void child(){
	System.out.println("hi im a child");
	}
	public void man() {
		System.out.println("hi im a man");
	}
}
class b extends A{
	public void bird(){
		System.out.println("hi im a bird");
		super.child();
		
		}
	public void man() {
		System.out.println("hi im a updated vesrion of man");
		
	}
}
	class c extends b{
		public void call() {
			super.bird();
			super.man();

		}
		public void show() {
			System.out.println("hi im a updated vesrion of c");
		}
	}
	

public class inher1 {
	public static void main(String[] args) {
		c ob=new c();
		ob.show();
		ob.call();
		
	}

}
