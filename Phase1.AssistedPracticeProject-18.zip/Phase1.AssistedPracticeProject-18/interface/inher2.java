package learning;
class call{
	double a=10.9;
	public void trick() {
		System.out.println("hello im a trickle function");
	}
}
public class inher2 extends  call{
String st="ritik";
public static void main(String[] args) {
	inher2 ob = new inher2();
	System.out.println("value of double is :"+ob.a);
	System.out.println("value of double is :"+ob.st);
	ob.trick();
}
}
