package trick;

class encap2{  
public static void main(String[] args)
{  

encap s=new encap();  
s.setName("ritik");   
System.out.println(s.getName());  
}  
}  