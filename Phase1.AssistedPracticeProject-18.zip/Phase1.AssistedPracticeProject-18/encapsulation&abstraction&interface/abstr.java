package trick;



interface inter{
	public void show();
	
}
interface inter2 extends inter{
	public void show1();

}
abstract class create{
	public abstract void show3();
}

class result extends create implements inter2{
public	void show3() {
		System.out.println(" im a inherited method of abstract function");
	}
	public void show1() {
		System.out.println(" im a inherited method of interface function 2");
	}
	public void show() {
		System.out.println(" im a inherited method of interface function 1");
	}
}
public class abstr {
	public static void main(String[] args) {
		result run= new result();
		run.show();
		run.show1();
		run.show3();
		
		}

}
