package learning;

class caller{  
	caller(int a){
		System.out.println("im a constructor");
	}
public int MUL(int a,int b){
	return a*b;
	}  
public int add(int a,int b,int c){
	
	return a+b+c; 
}  
}
class overload{  
public static void main(String[] args){ 
	caller call=new caller(10);
	System.out.println(call.add(12, 10, 50));
	System.out.println(call.MUL(18, 10));

	
	
  
}
}  