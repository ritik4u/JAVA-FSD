package learning;

class MY {
	 public void Hi() {
	  System.out.println("HI I AM A ROBERT");
	 }
	}
	class yes extends MY {
	 public void Hi() {
	  System.out.println("HI I AM A PETER");
	 }
	}
	public class override1{
	 public static void main(String args[]) {
	  MY a = new MY();
	  yes b = new yes();
	  a.Hi();
	  b.Hi();
	 }
	}
