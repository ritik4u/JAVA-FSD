package simpli;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class handle {
	public static void main(String[] args)  {
		
		File f1 = new File("E://practo//ritik1.txt");
		try {
			if(f1.createNewFile())
			{
				System.out.println("File  ritik is created");
			}else
			{
				System.out.println("file is already available");
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	
		try {
			FileWriter f2 = new FileWriter(f1);
			f2.write("HELLO I AM RITIK CREATOR OF THIS FILE ");
			f2.write("\n I LOVE MY COUNTRY(INDIA)");
			f2.append("\n I LOVE TO DO CODING");
			f2.append("\n I WELL THANK YOU FOR READING)");
			f2.append("\n HAVE A NICE DAY");
			f2.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
 try {  
			 
			 File f3 = new File("E://practo//ritik1.txt"); 
	            Scanner sc = new Scanner(f3);  
	            while (sc.hasNextLine()) {  
	                String info = sc.nextLine();  
	                System.out.println(info);  
	            }  
	            sc.close();  
	        } catch (FileNotFoundException exception) {  
	            System.out.println("Unexcpected error occurred!");  
	            exception.printStackTrace();  
	        }  
		
	}

}

