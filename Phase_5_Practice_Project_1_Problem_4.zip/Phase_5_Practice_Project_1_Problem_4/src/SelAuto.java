import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelAuto {
public static void main(String[] args) throws InterruptedException {
	//register the chrome driver
	System.setProperty("webdriver.chrome.driver","B:\\Phase 5 - Selenium\\95\\chromedriver.exe");
	//create an obj to the driver -obj to the browser
	WebDriver wd=new ChromeDriver();//wd is the controller obj to web browser
	//maxmize the screen
	wd.manage().window().maximize();
	//web url 
	wd.manage().timeouts().pageLoadTimeout(2000,TimeUnit.MILLISECONDS);
	wd.get("http://127.0.0.1:5501/register.html");
	//wd.manage().timeouts().implicitlyWait(10,TimeUnit.NANOSECONDS);
	WebElement we1=wd.findElement(By.name("id"));
	WebElement we2=wd.findElement(By.name("op"));
	explicit(wd,we1,200,"1");
	explicitSelect(wd,we2,300);
}


public static void explicit(WebDriver wd,WebElement we,int timeout,String value) {
	new WebDriverWait(wd, timeout).until(ExpectedConditions.visibilityOf(we));
	we.sendKeys(value);
}

public static void explicitSelect(WebDriver wd, WebElement we, int timeout) {
	new WebDriverWait(wd, timeout).until(ExpectedConditions.visibilityOf(we));
	Select sc=new Select(we);
	sc.selectByVisibleText("JAVA");
}


}
