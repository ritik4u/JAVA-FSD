package simpli;

public class inner {
	class ritik{
		public void show() {
			System.out.println("hello java");
			
		}
	}
		class s{
			public void rat() {
				System.out.println("hello claasic word");
		}
	}
		public void yes() {
			System.out.println("inner class function !!!!");
		}
		public static void main(String args[]) {
			inner i =new inner();
			
			inner.s o =i.new s();
			inner.ritik m=i.new ritik();
			i.yes();
			o.rat();
			m.show();
			
			
			
			
		}

}




