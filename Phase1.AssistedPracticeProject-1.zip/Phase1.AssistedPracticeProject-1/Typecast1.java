package simpli;



class Typecast1{
	  public static void main(String[] args) {
		  
	   int i=10;
	   long l=i;
	   float f =l;
	   double d =f;
	   String s =String.valueOf(i);
	   System.out.println("value of integer"+i);
	   System.out.println("value of long"+l);
	   System.out.println("value of float"+f);
	   System.out.println("value of double"+d);
	   System.out.println("string "+s);
	   
	   
	    
	  }
	}

