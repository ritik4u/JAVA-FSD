package simpli;
import java.util.*;
public class Typecast2 {
public static void main(String args[]) {
	Scanner sc = new Scanner (System.in);
	System.out.println("enter integer to typecast");
	int n= sc.nextInt();
	short m=(short)n;//typecast int to short
	System.out.println("typecast variable integer"+m);
	System.out.println("enter long to typecast");
	long l= sc.nextInt();
	int i=(int)l;// typecast long to int
	System.out.println("typecast variable long is"+i);
	System.out.println("enter double to typecast");
	double q=sc.nextInt();
	long t=(long)q;//typecast double to long
    System.out.println("typecast variable is"+t);
    String string="1223444";
    int c =Integer.parseInt(string);//typecast string to int
    System.out.println("typecast variable is"+c);
    float f=sc.nextInt();
    int k=(int)f;//typecast float to int 
    System.out.println("typecast variable is"+k);
  
	
	
}
}
