import { Component } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  toggleImage(): void {
    const imageElement = document.getElementById('myImage') as HTMLImageElement;
    if (imageElement.style.display === 'none') {
      imageElement.style.display = 'block';
    } else {
      imageElement.style.display = 'none';
    }
  }

  isButtonDisabled: boolean = false;

  ProductList: Product[] = [
    new Product('Leaf Rake', 'GDN-0011', 'March 19, 2016', 19.95, 3.5),
    new Product('Garden Cart', 'GDN-0023', 'March 18, 2016', 32.99, 4.2),
    new Product('Pruning Shears', 'GDN-0045', 'March 22, 2016', 8.99, 4.0),
    new Product('Leaf Blower', 'GDN-0088', 'March 15, 2016', 99.99, 4.8),
  ];
}

class Product {
  constructor(
    public name: string,
    public code: string,
    public available: string,
    public price: number,
    public rating: number
  ) {}
}
