package simpli;

class Array{  
public static void main(String args[]){  
int a[]={33,3,4,5};  
for(int i=0;i<a.length;i++)
System.out.println(a[i]);  
int b[][]={{2,2,4},{6,0,5},{0,4,9}};  
for(int j=0;j<3;j++){  
	 for(int k=0;k<3;k++){  
	   System.out.print(b[j][k]+" ");
	 }
}
System.out.println("\nlength of array"+b.length);

}
}  
