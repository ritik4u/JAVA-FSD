package simpli;

import java.io.InterruptedIOException;

public class sleepwait {
	private static Object call  = new Object();
public static void main(String[] args)throws InterruptedIOException, InterruptedException {
	Thread.sleep(3500);
	System.out .println(Thread.currentThread().getName()+"thread is sleeping");
	synchronized (call) {
	call.wait(3500);
	System.out .println(call+"object is in waitiing state");

	}
	
}
}
