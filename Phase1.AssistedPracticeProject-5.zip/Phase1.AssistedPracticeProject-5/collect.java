package simpli;

import java.util.*;

public class collect {
public static void main(String args[]) {
	ArrayList<String>names=new ArrayList<String>();
	names.add("ritik");
	names.add("phastos");
	names.add("lily");
	names.add("tree");
	System.out.println(names.contains("ritik"));
	names.remove("lily");
	System.out.println(names.size());
	System.out.println("names of list"+names);
	//linked list
	LinkedList l=new LinkedList<>();
	l.addAll(names);
	l.add("hello");
	l.add(101);
	l.add("the");
	System.out.println(names.contains("hello"));
	l.remove("the");
	System.out.println(l.size());
	System.out.println("names of list"+l);
	System.out.println(l.isEmpty());
	//stack
	Stack<Integer> s= new Stack<>(); 
	s.push(10);
	s.push(20);
	s.push(80);
	s.push(40);
	s.pop();
	System.out.println(s.peek());
	System.out.println(s);
	//queue
	Queue q=new LinkedList();
	q.offer("ct");
	q.offer("b");
	q.offer("a");
	q.offer("r");
	q.poll();
	System.out.println(q.peek());
	System.out.println(q);
	 //vector
		Vector<Integer> v = new Vector();
	    v.addElement(15); 
	    v.addElement(30); 
	    System.out.println(v);
	    // hashset
	    HashSet<Integer> Z=new HashSet<Integer>();  
	    Z.add(10111);  
	    Z.add(10113);  
	    Z.add(1012);
	    Z.add(1014);
	    System.out.println(Z);
	    
	    //linkedhashset
	    
	    LinkedHashSet<Integer> B=new LinkedHashSet<Integer>();  
	    B.add(112);  
	    B.add(1390);  
	    B.add(1212);
	    B.add(1411);	       
	    System.out.println(B);
	
   	} 

}

