package simpli;
 class j{
	j(){
		System.out.println("hi im a constructor");
	}
	
	j(int a,int b){
		int c=a+b;
		System.out.println("hi im a parametrized constructor"+" "+c);
	}
	j(int a,int b ,int c){
	int	d=a*b*c;
	System.out.println("hi im a parametrized constructor 2"+""+d);
	}
}
public class construct {
	public static void main(String args[]) {
		j ob=new j();//first constructor called
		j p =new j(1,2);// second called
		j e = new j(1,2,3);// third called
		
		
	}
	

}
