package practo1;
import java.util.Scanner;
public class increasing {
public static void main(String[] args) {
Scanner scanner= new Scanner(System.in);
System.out.println("enter a length");
int n=scanner.nextInt();
int a[]=new int[n];
System.out.println("enter elements");
for(int i=0;i<n;i++) {
a[i]=scanner.nextInt();
}
int omax=0;
int dp[]= new int[n];
for(int i=0;i<dp.length;i++) {
int max=0;
for(int j=0;j<i;j++) {
if(a[j]<a[i]) {
if(dp[j]>max) {
max=dp[j];
}
}
}
dp[i]=max+1;
if(dp[i]>omax){
omax=dp[i];
}
}
System.out.println(" length of longest increasing Subsequence is"+" "+omax);
}
}