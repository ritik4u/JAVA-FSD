package sort;



public class Bubblesort {
	
	
	

	public static void main(String args[]) {
		
	
		int a[]= {19,147,3,10,16,256};
		int n=a.length;
		for(int i=0;i<=n-1;i++) {
			int flag=0;
			for(int j=0;j<n-1-i;j++) {
				int temp;
				if(a[j]>a[j+1]) {
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
					flag=1;
				}
				
			}
			if(flag==0) {
				break;
			}
			
		}
		for(int i=0;i<=n-1;i++) {
			System.out.println("the sorted array is"+a[i]);
		}
		
		
		
	
		
	}

}












