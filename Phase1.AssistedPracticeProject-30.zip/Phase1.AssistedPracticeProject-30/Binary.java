package sort;

public class Binary {
	public static int binarysearch(int numbers[],int key) {
		int start=0;
		int end=numbers.length-1;
		while(start<=end) {
			int mid=(start+end)/2;
			if(numbers[mid]==key) {
				return  mid;
				
			}
			if(numbers[mid]<key) {
				start=mid+1; 
			}
			else {
				end=mid-1;
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		int numbers[]= {12,15,18,21,34};
		int n=numbers.length;
		int key=18;
		System.out.println( "element found at :"+" "+binarysearch(numbers, key));   
		
		
	}

}
