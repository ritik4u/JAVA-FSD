package simpli;
import java.util.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class REG {
	public static void main(String args[]) {
		Pattern pat =Pattern.compile(".m");
		Matcher m=pat.matcher(".am");
		Boolean b =m.matches();
		System.out.println(b);
		
		System.out.println(Pattern.matches("[amn]","acd"));
		System.out.println(Pattern.matches("[^amn]","c"));
		System.out.println(Pattern.matches("[a-zA-Z]","T"));
		System.out.println(Pattern.matches("[MS][a-z]{5}","Manya"));
		System.out.println(Pattern.matches("[xyz]?","x"));
		System.out.println(Pattern.matches("[xyz]+","x"));
		System.out.println(Pattern.matches("[xyz]*","xyyza"));
		System.out.println(Pattern.matches("\\d","1"));
		System.out.println(Pattern.matches("\\D","1"));
		
		
		
	}

}

}
